#include "Personagem.h"
#include <iostream>
#include <string>


using std::cout, std::endl;

int main ()
{
    Personagem p1("Luke Skywalker", "Luke Skywalker", "Star Wars");
    Personagem p2("Darth Vader", "Darth Vader", "Star Wars");
    Personagem p3("Han Solo", "Han Solo", "Star Wars");
    Personagem p4("Chewbacca", "Chewbacca", "Star Wars");
    Personagem p5("Leia Organa", "Leia Organa", "Star Wars");
    Personagem p6("Obi-Wan Kenobi", "Obi-Wan Kenobi", "Star Wars");
    Personagem p7("R2-D2", "R2-D2", "Star Wars");
    Personagem p8("C-3PO", "C-3PO", "Star Wars");
    Personagem p9("Yoda", "Yoda", "Star Wars");
    Personagem p10("Darth Maul", "Darth Maul", "Star Wars");
    Personagem p11("Jango Fett", "Jango Fett", "Star Wars");
    Personagem p12("Boba Fett", "Boba Fett", "Star Wars");
    Personagem p13("Emperor Palpatine", "Emperor Palpatine", "Star Wars");
    Personagem p14("Padmé Amidala", "Padmé Amidala", "Star Wars");
    Personagem p15("Anakin Skywalker", "Anakin Skywalker", "Star Wars");
    Personagem p16("Mace Windu", "Mace Windu", "Star Wars");
    Personagem p17("Ki-Adi-Mundi", "Ki-Adi-Mundi", "Star Wars");
    Personagem p18("Count Dooku", "Count Dooku", "Star Wars");
    Personagem p19("Bail Prestor Organa", "Bail Prestor Organa", "Star Wars");
    Personagem p20("Jabba Desilijic Tiure", "Jabba Desilijic Tiure", "Star Wars");
    Personagem p21("Watto", "Watto", "Star Wars");
    Personagem p22("Rugor Nass", "Rugor Nass", "Star Wars");
    Personagem p23("Nute Gunray", "Nute Gunray", "Star Wars");
    Personagem p24("Finis Valorum");
    
    p1.displayMessage();
    p2.displayMessage();
    p3.displayMessage();
    p4.displayMessage();
    p5.displayMessage();
    p6.displayMessage();
    p7.displayMessage();
    p8.displayMessage();
    p9.displayMessage();
    p10.displayMessage();
    p11.displayMessage();
    p12.displayMessage();
    p13.displayMessage();
    p14.displayMessage();
    p15.displayMessage();
    p16.displayMessage();
    p17.displayMessage();
    p18.displayMessage();
    p19.displayMessage();
    p20.displayMessage();
    p21.displayMessage();
    p22.displayMessage();
    p23.displayMessage();
    p24.displayMessage();
    
    return 0;
}