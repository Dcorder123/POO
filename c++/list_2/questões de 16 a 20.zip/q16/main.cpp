#include "Carro.h"

int main() {
  
  Carro carroTeste1("");

  carroTeste1.displayMessage();


  Carro carroTeste2("Uma marca bem grande");
  carroTeste2.displayMessage();

  return 0;
}